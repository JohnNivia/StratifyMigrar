
package com.example.repository;

import com.example.entity.HistorialAdmin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HistorialAdminRepository extends JpaRepository<HistorialAdmin, Integer> {
    List<HistorialAdmin> findAllByOrderByFechaAccionDesc();
    List<HistorialAdmin> findByIdAdminOrderByFechaAccionDesc(Integer idAdmin);
    List<HistorialAdmin> findByTablaAfectadaOrderByFechaAccionDesc(String tablaAfectada);
}