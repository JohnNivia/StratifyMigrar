
package com.example.repository;

import com.example.entity.Solicitud;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SolicitudRepository extends JpaRepository<Solicitud, Integer> {
    List<Solicitud> findAllByOrderByFechaSolicitudDesc();
    List<Solicitud> findByEstadoOrderByFechaSolicitudDesc(String estado);
    List<Solicitud> findByUsuarioIdUsuarioOrderByFechaSolicitudDesc(Integer idUsuario);
    List<Solicitud> findByProveedorIdProveedorOrderByFechaSolicitudDesc(Integer idProveedor);

    long countByEstado(String estado);
}