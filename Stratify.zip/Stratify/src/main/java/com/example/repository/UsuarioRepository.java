package com.example.repository;

import com.example.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    Optional<Usuario> findByCorreo(String correo);
    Optional<Usuario> findByNumeroDocumento(String numeroDocumento);
    Optional<Usuario> findByTokenRecuperacion(String tokenRecuperacion);

    boolean existsByCorreo(String correo);
    boolean existsByNumeroDocumento(String numeroDocumento);

    List<Usuario> findByRolNombreRol(String nombreRol);
    List<Usuario> findByEstado(String estado);
    List<Usuario> findByAutorizacion(Boolean autorizacion);
}