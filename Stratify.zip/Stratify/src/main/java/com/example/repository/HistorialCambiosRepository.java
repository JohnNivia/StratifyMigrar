package com.example.repository;

import com.example.entity.HistorialCambios;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HistorialCambiosRepository extends JpaRepository<HistorialCambios, Integer> {
    List<HistorialCambios> findAllByOrderByFechaCambioDesc();
    List<HistorialCambios> findByProductoIdProductoOrderByFechaCambioDesc(Integer idProducto);
    List<HistorialCambios> findByUsuarioIdUsuarioOrderByFechaCambioDesc(Integer idUsuario);
    List<HistorialCambios> findByTipoCambioOrderByFechaCambioDesc(String tipoCambio);
}