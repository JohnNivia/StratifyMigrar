package com.example.repository;

import com.example.entity.UbicacionAlmacen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UbicacionAlmacenRepository extends JpaRepository<UbicacionAlmacen, Integer> {
    List<UbicacionAlmacen> findByEstado(String estado);
    List<UbicacionAlmacen> findByCiudadIgnoreCase(String ciudad);
    List<UbicacionAlmacen> findByNombreContainingIgnoreCase(String nombre);
}