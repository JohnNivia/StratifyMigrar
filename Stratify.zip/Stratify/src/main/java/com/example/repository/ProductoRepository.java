package com.example.repository;

import com.example.entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Integer> {
    Optional<Producto> findByCodigoProducto(String codigoProducto);
    boolean existsByCodigoProducto(String codigoProducto);

    List<Producto> findByEstado(String estado);
    List<Producto> findByUbicacionAlmacenIdUbicacion(Integer idUbicacion);
    List<Producto> findByProveedorIdProveedor(Integer idProveedor);
    List<Producto> findByNombreContainingIgnoreCase(String nombre);

    @Query("SELECT p FROM Producto p WHERE p.inventario.cantidadActual <= p.inventario.stockMinimo")
    List<Producto> findProductosConStockBajo();
}