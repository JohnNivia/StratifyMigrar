
package com.example.repository;

import com.example.entity.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProveedorRepository extends JpaRepository<Proveedor, Integer> {
    Optional<Proveedor> findByNit(String nit);
    Optional<Proveedor> findByCorreo(String correo);
    List<Proveedor> findByEstado(String estado);
    List<Proveedor> findByNombreContainingIgnoreCase(String nombre);
    boolean existsByNit(String nit);
}