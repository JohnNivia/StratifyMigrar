package com.example.service;

import com.example.entity.Rol;
import com.example.entity.TipoDocumento;
import com.example.entity.Usuario;
import com.example.repository.RolRepository;
import com.example.repository.TipoDocumentoRepository;
import com.example.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final TipoDocumentoRepository tipoDocumentoRepository;
    private final EmailService emailService;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public Usuario autenticar(String correo, String contrasenaPlana) {
        Usuario usuario = usuarioRepository.findByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("Credenciales inválidas."));

        if (!passwordEncoder.matches(contrasenaPlana, usuario.getContrasena())) {
            throw new RuntimeException("Credenciales inválidas.");
        }

        if (Boolean.FALSE.equals(usuario.getAutorizacion())) {
            throw new RuntimeException("Tu cuenta aún no ha sido autorizada por un administrador.");
        }

        if (usuario.getEstado() != null && !usuario.getEstado().equalsIgnoreCase("Activo")) {
            throw new RuntimeException("Tu cuenta se encuentra en estado: " + usuario.getEstado());
        }

        return usuario;
    }

    @Transactional
    public Usuario registrarUsuario(Usuario nuevoUsuario, Integer idTipoDocumento, Integer idRol) {
        if (usuarioRepository.existsByCorreo(nuevoUsuario.getCorreo())) {
            throw new RuntimeException("El correo ya está registrado.");
        }
        if (usuarioRepository.existsByNumeroDocumento(nuevoUsuario.getNumeroDocumento())) {
            throw new RuntimeException("El número de documento ya está registrado.");
        }

        TipoDocumento tipoDoc = tipoDocumentoRepository.findById(idTipoDocumento)
                .orElseThrow(() -> new RuntimeException("Tipo de documento no válido."));

        Rol rol = (idRol != null)
                ? rolRepository.findById(idRol).orElseThrow(() -> new RuntimeException("Rol no válido."))
                : rolRepository.findByNombreRol("Usuario")
                .orElseThrow(() -> new RuntimeException("Rol por defecto no encontrado."));

        nuevoUsuario.setTipoDocumento(tipoDoc);
        nuevoUsuario.setRol(rol);
        nuevoUsuario.setContrasena(passwordEncoder.encode(nuevoUsuario.getContrasena()));
        nuevoUsuario.setEstado("Pendiente");
        nuevoUsuario.setAutorizacion(false);

        return usuarioRepository.save(nuevoUsuario);
    }

    @Transactional
    public void solicitarRecuperacionContrasena(String correo, String baseUrl) {
        Usuario usuario = usuarioRepository.findByCorreo(correo)
                .orElseThrow(() -> new RuntimeException("No existe un usuario registrado con ese correo."));

        String token = UUID.randomUUID().toString();
        usuario.setTokenRecuperacion(token);
        usuario.setFechaExpiracionToken(LocalDateTime.now().plusMinutes(30));
        usuarioRepository.save(usuario);

        String enlace = baseUrl + "/restablecer-clave?token=" + token;
        emailService.enviarCorreoRecuperacion(usuario.getCorreo(), usuario.getNombre(), enlace);
    }

    public Optional<Usuario> validarTokenRecuperacion(String token) {
        return usuarioRepository.findByTokenRecuperacion(token)
                .filter(u -> u.getFechaExpiracionToken() != null
                        && u.getFechaExpiracionToken().isAfter(LocalDateTime.now()));
    }

    @Transactional
    public void restablecerContrasena(String token, String nuevaContrasena) {
        Usuario usuario = validarTokenRecuperacion(token)
                .orElseThrow(() -> new RuntimeException("El enlace de recuperación es inválido o ha expirado."));

        usuario.setContrasena(passwordEncoder.encode(nuevaContrasena));
        usuario.setTokenRecuperacion(null);
        usuario.setFechaExpiracionToken(null);
        usuarioRepository.save(usuario);
    }
}