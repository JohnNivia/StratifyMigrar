package com.example.service;

import com.example.entity.HistorialAdmin;
import com.example.entity.HistorialCambios;
import com.example.entity.Producto;
import com.example.entity.Usuario;
import com.example.repository.HistorialAdminRepository;
import com.example.repository.HistorialCambiosRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class HistorialService {

    private final HistorialCambiosRepository historialCambiosRepository;
    private final HistorialAdminRepository historialAdminRepository;

    public List<HistorialCambios> listarHistorialCambios() {
        return historialCambiosRepository.findAllByOrderByFechaCambioDesc();
    }

    public List<HistorialCambios> listarCambiosPorProducto(Integer idProducto) {
        return historialCambiosRepository.findByProductoIdProductoOrderByFechaCambioDesc(idProducto);
    }

    public List<HistorialAdmin> listarHistorialAdmin() {
        return historialAdminRepository.findAllByOrderByFechaAccionDesc();
    }

    @Transactional
    public void registrarCambioInventario(Producto producto, Usuario usuario, String tipoCambio,
                                          Integer cantidadAnterior, Integer cantidadNueva, String descripcion) {
        HistorialCambios registro = new HistorialCambios();
        registro.setProducto(Producto);
        registro.setUsuario(usuario);
        registro.setTipoCambio(tipoCambio);
        registro.setCantidadAnterior(cantidadAnterior);
        registro.setCantidadNueva(cantidadNueva);
        registro.setDescripcion(descripcion);
        historialCambiosRepository.save(registro);
    }

    @Transactional
    public void registrarAccionAdmin(Usuario admin, String accion, String tablaAfectada, String detalle) {
        HistorialAdmin registro = new HistorialAdmin();
        if (admin != null) {
            registro.setIdAdmin(admin.getIdUsuario());
            registro.setNombreAdmin(admin.getNombre() + " " + admin.getApellido());
        }
        registro.setAccion(accion);
        registro.setTablaAfectada(tablaAfectada);
        registro.setDetalle(detalle);
        historialAdminRepository.save(registro);
    }
}