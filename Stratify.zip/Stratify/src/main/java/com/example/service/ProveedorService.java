package com.example.service;

import com.example.entity.Proveedor;
import com.example.entity.Usuario;
import com.example.repository.ProveedorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProveedorService {

    private final ProveedorRepository proveedorRepository;
    private final HistorialService historialService;

    public List<Proveedor> listarTodos() {
        return proveedorRepository.findAll();
    }

    public List<Proveedor> listarActivos() {
        return proveedorRepository.findByEstado("Activo");
    }

    public Optional<Proveedor> buscarPorId(Integer id) {
        return proveedorRepository.findById(id);
    }

    public Optional<Proveedor> buscarPorCorreo(String correo) {
        return proveedorRepository.findByCorreo(correo);
    }

    @Transactional
    public Proveedor guardarProveedor(Proveedor proveedor, Usuario adminEjecutor) {
        if (proveedor.getIdProveedor() == null && proveedor.getNit() != null
                && proveedorRepository.existsByNit(proveedor.getNit())) {
            throw new RuntimeException("Ya existe un proveedor con el NIT: " + proveedor.getNit());
        }
        if (proveedor.getEstado() == null || proveedor.getEstado().isBlank()) {
            proveedor.setEstado("Activo");
        }

        boolean esNuevo = (proveedor.getIdProveedor() == null);
        Proveedor guardado = proveedorRepository.save(proveedor);

        if (adminEjecutor != null) {
            historialService.registrarAccionAdmin(
                    adminEjecutor,
                    esNuevo ? "CREAR_PROVEEDOR" : "ACTUALIZAR_PROVEEDOR",
                    "proveedor",
                    "Proveedor: " + guardado.getNombre() + " (NIT: " + guardado.getNit() + ")"
            );
        }

        return guardado;
    }

    @Transactional
    public void cambiarEstado(Integer idProveedor, String estado, Usuario adminEjecutor) {
        Proveedor proveedor = proveedorRepository.findById(idProveedor)
                .orElseThrow(() -> new RuntimeException("Proveedor no encontrado."));
        proveedor.setEstado(estado);
        proveedorRepository.save(proveedor);

        if (adminEjecutor != null) {
            historialService.registrarAccionAdmin(
                    adminEjecutor,
                    "ESTADO_PROVEEDOR",
                    "proveedor",
                    "Cambió estado de " + proveedor.getNombre() + " a " + estado
            );
        }
    }
}