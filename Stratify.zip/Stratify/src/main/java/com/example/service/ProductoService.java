package com.example.service;

import com.example.entity.*;
import com.example.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductoService {

    private final ProductoRepository productoRepository;
    private final UnidadMedidaRepository unidadMedidaRepository;
    private final ProveedorRepository proveedorRepository;
    private final UbicacionAlmacenRepository ubicacionAlmacenRepository;
    private final HistorialService historialService;

    public List<Producto> listarTodos() {
        return productoRepository.findAll();
    }

    public List<Producto> listarActivos() {
        return productoRepository.findByEstado("Activo");
    }

    public List<Producto> listarStockBajo() {
        return productoRepository.findProductosConStockBajo();
    }

    public Optional<Producto> buscarPorId(Integer id) {
        return productoRepository.findById(id);
    }

    public List<Producto> buscarPorNombre(String nombre) {
        return productoRepository.findByNombreContainingIgnoreCase(nombre);
    }

    public List<Producto> listarPorUbicacion(Integer idUbicacion) {
        return productoRepository.findByUbicacionAlmacenIdUbicacion(idUbicacion);
    }

    public List<Producto> listarPorProveedor(Integer idProveedor) {
        return productoRepository.findByProveedorIdProveedor(idProveedor);
    }

    @Transactional
    public Producto crearProducto(Producto producto, Integer idUnidad, Integer idProveedor, Integer idUbicacion,
                                  int cantidadInicial, int stockMinimo, int stockMaximo, Usuario usuarioResponsable) {
        if (productoRepository.existsByCodigoProducto(producto.getCodigoProducto())) {
            throw new RuntimeException("Ya existe un producto con el código: " + producto.getCodigoProducto());
        }

        UnidadMedida unidad = unidadMedidaRepository.findById(idUnidad)
                .orElseThrow(() -> new RuntimeException("Unidad de medida no encontrada."));
        Proveedor proveedor = proveedorRepository.findById(idProveedor)
                .orElseThrow(() -> new RuntimeException("Proveedor no encontrado."));
        UbicacionAlmacen ubicacion = ubicacionAlmacenRepository.findById(idUbicacion)
                .orElseThrow(() -> new RuntimeException("Ubicación de almacén no encontrada."));

        Inventario inventario = new Inventario();
        inventario.setCantidadActual(cantidadInicial);
        inventario.setStockMinimo(stockMinimo);
        inventario.setStockMaximo(stockMaximo);

        producto.setUnidadMedida(unidad);
        producto.setProveedor(proveedor);
        producto.setUbicacionAlmacen(ubicacion);
        producto.setInventario(inventario);
        if (producto.getEstado() == null || producto.getEstado().isBlank()) {
            producto.setEstado("Activo");
        }

        Producto guardado = productoRepository.save(producto);

        if (usuarioResponsable != null) {
            historialService.registrarCambioInventario(
                    guardado,
                    usuarioResponsable,
                    "CREACION",
                    0,
                    cantidadInicial,
                    "Registro inicial del producto en sede: " + ubicacion.getNombre()
            );
        }

        return guardado;
    }

    @Transactional
    public Producto actualizarProducto(Integer idProducto, Producto datos, Integer idUnidad, Integer idProveedor,
                                       Integer idUbicacion, Integer stockMinimo, Integer stockMaximo, Usuario usuarioResponsable) {
        Producto existente = productoRepository.findById(idProducto)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        existente.setCodigoProducto(datos.getCodigoProducto());
        existente.setNombre(datos.getNombre());
        existente.setDescripcion(datos.getDescripcion());
        existente.setPrecioUnitario(datos.getPrecioUnitario());
        if (datos.getEstado() != null) {
            existente.setEstado(datos.getEstado());
        }

        if (idUnidad != null) {
            existente.setUnidadMedida(unidadMedidaRepository.findById(idUnidad)
                    .orElseThrow(() -> new RuntimeException("Unidad de medida no encontrada.")));
        }
        if (idProveedor != null) {
            existente.setProveedor(proveedorRepository.findById(idProveedor)
                    .orElseThrow(() -> new RuntimeException("Proveedor no encontrado.")));
        }
        if (idUbicacion != null) {
            existente.setUbicacionAlmacen(ubicacionAlmacenRepository.findById(idUbicacion)
                    .orElseThrow(() -> new RuntimeException("Ubicación no encontrada.")));
        }

        if (existente.getInventario() != null) {
            if (stockMinimo != null) existente.getInventario().setStockMinimo(stockMinimo);
            if (stockMaximo != null) existente.getInventario().setStockMaximo(stockMaximo);
        }

        Producto actualizado = productoRepository.save(existente);

        if (usuarioResponsable != null) {
            int cant = actualizado.getInventario() != null ? actualizado.getInventario().getCantidadActual() : 0;
            historialService.registrarCambioInventario(
                    actualizado,
                    usuarioResponsable,
                    "EDICION",
                    cant,
                    cant,
                    "Actualización de ficha del producto"
            );
        }

        return actualizado;
    }

    @Transactional
    public void cambiarEstado(Integer idProducto, String estado) {
        Producto producto = productoRepository.findById(idProducto)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));
        producto.setEstado(estado);
        productoRepository.save(producto);
    }
}