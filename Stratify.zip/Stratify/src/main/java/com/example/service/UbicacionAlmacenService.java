package com.example.service;

import com.example.entity.UbicacionAlmacen;
import com.example.entity.Usuario;
import com.example.repository.UbicacionAlmacenRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UbicacionAlmacenService {

    private final UbicacionAlmacenRepository ubicacionRepository;
    private final HistorialService historialService;

    public List<UbicacionAlmacen> listarTodas() {
        return ubicacionRepository.findAll();
    }

    public List<UbicacionAlmacen> listarActivas() {
        return ubicacionRepository.findByEstado("Activo");
    }

    public Optional<UbicacionAlmacen> buscarPorId(Integer id) {
        return ubicacionRepository.findById(id);
    }

    @Transactional
    public UbicacionAlmacen guardarUbicacion(UbicacionAlmacen ubicacion, Usuario adminEjecutor) {
        if (ubicacion.getEstado() == null || ubicacion.getEstado().isBlank()) {
            ubicacion.setEstado("Activo");
        }

        boolean esNueva = (ubicacion.getIdUbicacion() == null);
        UbicacionAlmacen guardada = ubicacionRepository.save(ubicacion);

        if (adminEjecutor != null) {
            historialService.registrarAccionAdmin(
                    adminEjecutor,
                    esNueva ? "CREAR_UBICACION" : "ACTUALIZAR_UBICACION",
                    "ubicacion_almacen",
                    "Local/Sede: " + guardada.getNombre() + " - " + guardada.getDireccion()
            );
        }

        return guardada;
    }

    @Transactional
    public void cambiarEstado(Integer idUbicacion, String estado, Usuario adminEjecutor) {
        UbicacionAlmacen ubicacion = ubicacionRepository.findById(idUbicacion)
                .orElseThrow(() -> new RuntimeException("Ubicación no encontrada."));
        ubicacion.setEstado(estado);
        ubicacionRepository.save(ubicacion);

        if (adminEjecutor != null) {
            historialService.registrarAccionAdmin(
                    adminEjecutor,
                    "ESTADO_UBICACION",
                    "ubicacion_almacen",
                    "Cambió estado de sede " + ubicacion.getNombre() + " a " + estado
            );
        }
    }
}