package com.example.service;

import com.example.entity.Producto;
import com.example.entity.Solicitud;
import com.example.entity.Usuario;
import com.example.repository.ProductoRepository;
import com.example.repository.SolicitudRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SolicitudService {

    private final SolicitudRepository solicitudRepository;
    private final ProductoRepository productoRepository;
    private final InventarioService inventarioService;

    public List<Solicitud> listarTodas() {
        return solicitudRepository.findAllByOrderByFechaSolicitudDesc();
    }

    public List<Solicitud> listarPorEstado(String estado) {
        return solicitudRepository.findByEstadoOrderByFechaSolicitudDesc(estado);
    }

    public List<Solicitud> listarPorUsuario(Integer idUsuario) {
        return solicitudRepository.findByUsuarioIdUsuarioOrderByFechaSolicitudDesc(idUsuario);
    }

    public List<Solicitud> listarPorProveedor(Integer idProveedor) {
        return solicitudRepository.findByProveedorIdProveedorOrderByFechaSolicitudDesc(idProveedor);
    }

    public Optional<Solicitud> buscarPorId(Integer id) {
        return solicitudRepository.findById(id);
    }

    public long contarPendientes() {
        return solicitudRepository.countByEstado("PENDIENTE");
    }

    @Transactional
    public Solicitud crearSolicitud(Integer idProducto, int cantidadSolicitada, String observaciones, Usuario solicitante) {
        if (cantidadSolicitada <= 0) {
            throw new IllegalArgumentException("La cantidad solicitada debe ser mayor a cero.");
        }

        Producto producto = productoRepository.findById(idProducto)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        Solicitud solicitud = new Solicitud();
        solicitud.setProducto(producto);
        solicitud.setProveedor(producto.getProveedor());
        solicitud.setUsuario(solicitante);
        solicitud.setCantidadSolicitada(cantidadSolicitada);
        solicitud.setObservaciones(observaciones);
        solicitud.setEstado("PENDIENTE");

        return solicitudRepository.save(solicitud);
    }

    @Transactional
    public Solicitud responderSolicitud(Integer idSolicitud, String nuevoEstado, String observacionesRespuesta,
                                        boolean sumarAlInventario, Usuario responsable) {
        Solicitud solicitud = solicitudRepository.findById(idSolicitud)
                .orElseThrow(() -> new RuntimeException("Solicitud no encontrada."));

        solicitud.setEstado(nuevoEstado);
        solicitud.setFechaRespuesta(LocalDateTime.now());

        if (observacionesRespuesta != null && !observacionesRespuesta.isBlank()) {
            String obsActual = solicitud.getObservaciones() != null ? solicitud.getObservaciones() + " | " : "";
            solicitud.setObservaciones(obsActual + "Respuesta: " + observacionesRespuesta);
        }

        Solicitud actualizada = solicitudRepository.save(solicitud);

        if (sumarAlInventario && ("APROBADA".equalsIgnoreCase(nuevoEstado) || "ENTREGADA".equalsIgnoreCase(nuevoEstado))) {
            inventarioService.registrarEntrada(
                    solicitud.getProducto().getIdProducto(),
                    solicitud.getCantidadSolicitada(),
                    "Abastecimiento por solicitud #" + solicitud.getIdSolicitud(),
                    responsable
            );
        }

        return actualizada;
    }
}