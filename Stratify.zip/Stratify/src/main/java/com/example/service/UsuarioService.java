package com.example.service;

import com.example.entity.Rol;
import com.example.entity.TipoDocumento;
import com.example.entity.Usuario;
import com.example.repository.RolRepository;
import com.example.repository.TipoDocumentoRepository;
import com.example.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final TipoDocumentoRepository tipoDocumentoRepository;
    private final HistorialService historialService;
    private final EmailService emailService;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> buscarPorId(Integer id) {
        return usuarioRepository.findById(id);
    }

    public List<Usuario> listarPendientesAutorizacion() {
        return usuarioRepository.findByAutorizacion(false);
    }

    @Transactional
    public Usuario actualizarUsuario(Integer idUsuario, Usuario datos, Integer idRol, Integer idTipoDoc, Usuario adminEjecutor) {
        Usuario existente = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado."));

        existente.setNombre(datos.getNombre());
        existente.setApellido(datos.getApellido());
        existente.setTelefono(datos.getTelefono());
        existente.setCorreo(datos.getCorreo());
        existente.setNumeroDocumento(datos.getNumeroDocumento());

        if (idRol != null) {
            Rol rol = rolRepository.findById(idRol)
                    .orElseThrow(() -> new RuntimeException("Rol no encontrado."));
            existente.setRol(rol);
        }

        if (idTipoDoc != null) {
            TipoDocumento tipoDoc = tipoDocumentoRepository.findById(idTipoDoc)
                    .orElseThrow(() -> new RuntimeException("Tipo de documento no encontrado."));
            existente.setTipoDocumento(tipoDoc);
        }

        if (datos.getContrasena() != null && !datos.getContrasena().isBlank()) {
            existente.setContrasena(passwordEncoder.encode(datos.getContrasena()));
        }

        Usuario guardado = usuarioRepository.save(existente);

        if (adminEjecutor != null) {
            historialService.registrarAccionAdmin(
                    adminEjecutor,
                    "ACTUALIZAR_USUARIO",
                    "usuario",
                    "Actualizó los datos del usuario: " + guardado.getCorreo()
            );
        }

        return guardado;
    }

    @Transactional
    public void cambiarAutorizacionYEstado(Integer idUsuario, boolean autorizar, String nuevoEstado, Usuario adminEjecutor) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado."));

        usuario.setAutorizacion(autorizar);
        usuario.setEstado(nuevoEstado);
        usuarioRepository.save(usuario);

        if (adminEjecutor != null) {
            historialService.registrarAccionAdmin(
                    adminEjecutor,
                    autorizar ? "AUTORIZAR_USUARIO" : "DESHABILITAR_USUARIO",
                    "usuario",
                    "Usuario " + usuario.getCorreo() + " -> Estado: " + nuevoEstado + ", Autorizado: " + autorizar
            );
        }

        try {
            emailService.enviarNotificacionEstadoCuenta(usuario.getCorreo(), usuario.getNombre(), autorizar);
        } catch (Exception ignored) {
            // Evita revertir la transacción si el servidor SMTP falla
        }
    }

    @Transactional
    public void eliminarUsuario(Integer idUsuario, Usuario adminEjecutor) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado."));
        String correo = usuario.getCorreo();
        usuarioRepository.delete(usuario);

        if (adminEjecutor != null) {
            historialService.registrarAccionAdmin(
                    adminEjecutor,
                    "ELIMINAR_USUARIO",
                    "usuario",
                    "Eliminó al usuario: " + correo
            );
        }
    }
}