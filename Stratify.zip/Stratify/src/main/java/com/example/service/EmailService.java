package com.example.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username:noreply@stratify.com}")
    private String remitente;

    public void enviarCorreoRecuperacion(String destinatario, String nombreUsuario, String enlaceRecuperacion) {
        SimpleMailMessage mensaje = new SimpleMailMessage();
        mensaje.setFrom(remitente);
        mensaje.setTo(destinatario);
        mensaje.setSubject("Stratify - Recuperación de contraseña");
        mensaje.setText(
                "Hola " + nombreUsuario + ",\n\n" +
                        "Recibimos una solicitud para restablecer tu contraseña en Stratify.\n" +
                        "Haz clic en el siguiente enlace para crear una nueva clave (válido por 30 minutos):\n\n" +
                        enlaceRecuperacion + "\n\n" +
                        "Si no solicitaste este cambio, puedes ignorar este mensaje."
        );
        mailSender.send(mensaje);
    }

    public void enviarNotificacionEstadoCuenta(String destinatario, String nombreUsuario, boolean autorizada) {
        SimpleMailMessage mensaje = new SimpleMailMessage();
        mensaje.setFrom(remitente);
        mensaje.setTo(destinatario);
        mensaje.setSubject("Stratify - Actualización de estado de cuenta");
        String estadoTexto = autorizada
                ? "Tu cuenta ha sido autorizada y activada. Ya puedes iniciar sesión en el sistema."
                : "Tu cuenta ha sido deshabilitada temporalmente por un administrador.";
        mensaje.setText("Hola " + nombreUsuario + ",\n\n" + estadoTexto);
        mailSender.send(mensaje);
    }
}