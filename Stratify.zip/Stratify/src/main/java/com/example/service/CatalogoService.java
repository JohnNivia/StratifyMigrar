package com.example.service;

import com.example.entity.Rol;
import com.example.entity.TipoDocumento;
import com.example.entity.UnidadMedida;
import com.example.repository.PermisoRepository;
import com.example.repository.RolRepository;
import com.example.repository.TipoDocumentoRepository;
import com.example.repository.UnidadMedidaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CatalogoService {

    private final RolRepository rolRepository;
    private final PermisoRepository permisoRepository;
    private final TipoDocumentoRepository tipoDocumentoRepository;
    private final UnidadMedidaRepository unidadMedidaRepository;

    public List<Rol> listarRoles() {
        return rolRepository.findAll();
    }

    public List<Permiso> listarPermisos() {
        return permisoRepository.findAll();
    }

    public List<TipoDocumento> listarTiposDocumento() {
        return tipoDocumentoRepository.findAll();
    }

    public List<UnidadMedida> listarUnidadesMedida() {
        return unidadMedidaRepository.findAll();
    }
}