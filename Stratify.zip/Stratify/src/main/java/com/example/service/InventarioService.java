package com.example.service;

import com.example.entity.Inventario;
import com.example.entity.Producto;
import com.example.entity.Usuario;
import com.example.repository.InventarioRepository;
import com.example.repository.ProductoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InventarioService {

    private final InventarioRepository inventarioRepository;
    private final ProductoRepository productoRepository;
    private final HistorialService historialService;

    public List<Inventario> listarTodos() {
        return inventarioRepository.findAll();
    }

    public List<Inventario> listarConStockBajo() {
        return inventarioRepository.findInventariosConStockBajo();
    }

    @Transactional
    public Inventario registrarEntrada(Integer idProducto, int cantidad, String motivo, Usuario usuario) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad de entrada debe ser mayor a cero.");
        }

        Producto producto = productoRepository.findById(idProducto)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        Inventario inventario = producto.getInventario();
        int anterior = inventario.getCantidadActual();
        int nueva = anterior + cantidad;

        inventario.setCantidadActual(nueva);
        Inventario guardado = inventarioRepository.save(inventario);

        if (usuario != null) {
            historialService.registrarCambioInventario(
                    producto,
                    usuario,
                    "ENTRADA",
                    anterior,
                    nueva,
                    motivo != null && !motivo.isBlank() ? motivo : "Ingreso de mercancía al inventario"
            );
        }

        return guardado;
    }

    @Transactional
    public Inventario registrarSalida(Integer idProducto, int cantidad, String motivo, Usuario usuario) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad de salida debe ser mayor a cero.");
        }

        Producto producto = productoRepository.findById(idProducto)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        Inventario inventario = producto.getInventario();
        int anterior = inventario.getCantidadActual();

        if (anterior < cantidad) {
            throw new RuntimeException("Stock insuficiente. Disponible: " + anterior);
        }

        int nueva = anterior - cantidad;
        inventario.setCantidadActual(nueva);
        Inventario guardado = inventarioRepository.save(inventario);

        if (usuario != null) {
            historialService.registrarCambioInventario(
                    producto,
                    usuario,
                    "SALIDA",
                    anterior,
                    nueva,
                    motivo != null && !motivo.isBlank() ? motivo : "Salida de mercancía del inventario"
            );
        }

        return guardado;
    }

    @Transactional
    public Inventario ajustarStock(Integer idProducto, int nuevaCantidad, String motivo, Usuario usuario) {
        if (nuevaCantidad < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo.");
        }

        Producto producto = productoRepository.findById(idProducto)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado."));

        Inventario inventario = producto.getInventario();
        int anterior = inventario.getCantidadActual();

        inventario.setCantidadActual(nuevaCantidad);
        Inventario guardado = inventarioRepository.save(inventario);

        if (usuario != null) {
            historialService.registrarCambioInventario(
                    producto,
                    usuario,
                    "AJUSTE",
                    anterior,
                    nuevaCantidad,
                    motivo != null && !motivo.isBlank() ? motivo : "Ajuste manual de inventario"
            );
        }

        return guardado;
    }
}