package com.example.Controller;

import com.example.entity.Usuario;
import com.example.service.SolicitudService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/solicitudes")
@RequiredArgsConstructor
public class SolicitudController {

    private final SolicitudService solicitudService;

    @PostMapping("/crear")
    public String crearSolicitud(@RequestParam("idProducto") Integer idProducto,
                                 @RequestParam("cantidadSolicitada") int cantidadSolicitada,
                                 @RequestParam(value = "observaciones", required = false) String observaciones,
                                 HttpSession session,
                                 HttpServletRequest request,
                                 RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            solicitudService.crearSolicitud(idProducto, cantidadSolicitada, observaciones, usuario);
            redirectAttributes.addFlashAttribute("mensajeExito", "Solicitud de abastecimiento enviada.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    @PostMapping("/responder")
    public String responderSolicitud(@RequestParam("idSolicitud") Integer idSolicitud,
                                     @RequestParam("nuevoEstado") String nuevoEstado,
                                     @RequestParam(value = "observacionesRespuesta", required = false) String observacionesRespuesta,
                                     @RequestParam(value = "sumarAlInventario", defaultValue = "false") boolean sumarAlInventario,
                                     HttpSession session,
                                     HttpServletRequest request,
                                     RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            solicitudService.responderSolicitud(idSolicitud, nuevoEstado, observacionesRespuesta, sumarAlInventario, usuario);
            redirectAttributes.addFlashAttribute("mensajeExito", "Solicitud actualizada a estado: " + nuevoEstado);
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    private String redirigirOrigen(HttpServletRequest request, Usuario usuario) {
        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isBlank()) {
            return "redirect:" + referer;
        }
        String rol = usuario.getRol().getNombreRol();
        if (rol.equalsIgnoreCase("Admin") || rol.equalsIgnoreCase("Administrador")) return "redirect:/admin";
        if (rol.equalsIgnoreCase("Proveedor")) return "redirect:/proveedor";
        return "redirect:/usuario";
    }
}