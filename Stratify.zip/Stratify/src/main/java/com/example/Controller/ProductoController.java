package com.example.Controller;

import com.example.entity.Producto;
import com.example.entity.Usuario;
import com.example.service.ProductoService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/productos")
@RequiredArgsConstructor
public class ProductoController {

    private final ProductoService productoService;

    @PostMapping("/crear")
    public String crearProducto(@ModelAttribute Producto producto,
                                @RequestParam("idUnidad") Integer idUnidad,
                                @RequestParam("idProveedor") Integer idProveedor,
                                @RequestParam("idUbicacion") Integer idUbicacion,
                                @RequestParam("cantidadInicial") int cantidadInicial,
                                @RequestParam(value = "stockMinimo", defaultValue = "5") int stockMinimo,
                                @RequestParam(value = "stockMaximo", defaultValue = "100") int stockMaximo,
                                HttpSession session,
                                HttpServletRequest request,
                                RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            productoService.crearProducto(producto, idUnidad, idProveedor, idUbicacion,
                    cantidadInicial, stockMinimo, stockMaximo, usuario);
            redirectAttributes.addFlashAttribute("mensajeExito", "Producto registrado correctamente.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    @PostMapping("/actualizar")
    public String actualizarProducto(@RequestParam("idProducto") Integer idProducto,
                                     @ModelAttribute Producto datos,
                                     @RequestParam(value = "idUnidad", required = false) Integer idUnidad,
                                     @RequestParam(value = "idProveedor", required = false) Integer idProveedor,
                                     @RequestParam(value = "idUbicacion", required = false) Integer idUbicacion,
                                     @RequestParam(value = "stockMinimo", required = false) Integer stockMinimo,
                                     @RequestParam(value = "stockMaximo", required = false) Integer stockMaximo,
                                     HttpSession session,
                                     HttpServletRequest request,
                                     RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            productoService.actualizarProducto(idProducto, datos, idUnidad, idProveedor,
                    idUbicacion, stockMinimo, stockMaximo, usuario);
            redirectAttributes.addFlashAttribute("mensajeExito", "Producto actualizado correctamente.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    @PostMapping("/estado")
    public String cambiarEstado(@RequestParam("idProducto") Integer idProducto,
                                @RequestParam("estado") String estado,
                                HttpSession session,
                                HttpServletRequest request,
                                RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            productoService.cambiarEstado(idProducto, estado);
            redirectAttributes.addFlashAttribute("mensajeExito", "Estado del producto actualizado.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    private String redirigirOrigen(HttpServletRequest request, Usuario usuario) {
        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isBlank()) {
            return "redirect:" + referer;
        }
        String rol = usuario.getRol().getNombreRol();
        return (rol.equalsIgnoreCase("Admin") || rol.equalsIgnoreCase("Administrador"))
                ? "redirect:/admin" : "redirect:/usuario";
    }
}