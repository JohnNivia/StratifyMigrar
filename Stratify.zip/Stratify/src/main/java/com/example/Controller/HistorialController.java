package com.example.Controller;

import com.example.entity.HistorialAdmin;
import com.example.entity.HistorialCambios;
import com.example.service.HistorialService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/historial")
@RequiredArgsConstructor
public class HistorialController {

    private final HistorialService historialService;

    @GetMapping("/cambios")
    @ResponseBody
    public List<HistorialCambios> obtenerHistorialCambios() {
        return historialService.listarHistorialCambios();
    }

    @GetMapping("/cambios/producto/{idProducto}")
    @ResponseBody
    public List<HistorialCambios> obtenerHistorialPorProducto(@PathVariable Integer idProducto) {
        return historialService.listarCambiosPorProducto(idProducto);
    }

    @GetMapping("/admin")
    @ResponseBody
    public List<HistorialAdmin> obtenerHistorialAdmin() {
        return historialService.listarHistorialAdmin();
    }
}