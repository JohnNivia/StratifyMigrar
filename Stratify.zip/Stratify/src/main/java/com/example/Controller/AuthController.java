package com.example.Controller;

import com.example.entity.Usuario;
import com.example.service.AuthService;
import com.example.service.CatalogoService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final CatalogoService catalogoService;

    @GetMapping({"/", "/login"})
    public String mostrarInicio(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario != null) {
            return redirigirSegunRol(usuario);
        }
        model.addAttribute("tiposDocumento", catalogoService.listarTiposDocumento());
        model.addAttribute("roles", catalogoService.listarRoles());
        return "index";
    }

    @PostMapping("/login")
    public String iniciarSesion(@RequestParam("correo") String correo,
                                @RequestParam("contrasena") String contrasena,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        try {
            Usuario usuario = authService.autenticar(correo, contrasena);
            session.setAttribute("usuarioLogueado", usuario);
            return redirigirSegunRol(usuario);
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
            return "redirect:/";
        }
    }

    @PostMapping("/registro")
    public String registrarUsuario(@ModelAttribute Usuario usuario,
                                   @RequestParam("idTipoDocumento") Integer idTipoDocumento,
                                   @RequestParam(value = "idRol", required = false) Integer idRol,
                                   RedirectAttributes redirectAttributes) {
        try {
            authService.registrarUsuario(usuario, idTipoDocumento, idRol);
            redirectAttributes.addFlashAttribute("mensajeExito",
                    "Registro exitoso. Un administrador debe autorizar tu cuenta antes de ingresar.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return "redirect:/";
    }
    package com.example.Controller;

import com.example.entity.Usuario;
import com.example.service.AuthService;
import com.example.service.CatalogoService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

    @Controller
    @RequiredArgsConstructor
    public class AuthController {

        private final AuthService authService;
        private final CatalogoService catalogoService;

        @GetMapping({"/", "/login"})
        public String mostrarInicio(HttpSession session, Model model) {
            Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
            if (usuario != null) {
                return redirigirSegunRol(usuario);
            }
            model.addAttribute("tiposDocumento", catalogoService.listarTiposDocumento());
            model.addAttribute("roles", catalogoService.listarRoles());
            return "index";
        }

        @PostMapping("/login")
        public String iniciarSesion(@RequestParam("correo") String correo,
                                    @RequestParam("contrasena") String contrasena,
                                    HttpSession session,
                                    RedirectAttributes redirectAttributes) {
            try {
                Usuario usuario = authService.autenticar(correo, contrasena);
                session.setAttribute("usuarioLogueado", usuario);
                return redirigirSegunRol(usuario);
            } catch (RuntimeException e) {
                redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
                return "redirect:/";
            }
        }

        @PostMapping("/registro")
        public String registrarUsuario(@ModelAttribute Usuario usuario,
                                       @RequestParam("idTipoDocumento") Integer idTipoDocumento,
                                       @RequestParam(value = "idRol", required = false) Integer idRol,
                                       RedirectAttributes redirectAttributes) {
            try {
                authService.registrarUsuario(usuario, idTipoDocumento, idRol);
                redirectAttributes.addFlashAttribute("mensajeExito",
                        "Registro exitoso. Un administrador debe autorizar tu cuenta antes de ingresar.");
            } catch (RuntimeException e) {
                redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
            }
            return "redirect:/";
        }

        @PostMapping("/recuperar-clave")
        public String solicitarRecuperacion(@RequestParam("correo") String correo,
                                            HttpServletRequest request,
                                            RedirectAttributes redirectAttributes) {
            try {
                String baseUrl = request.getScheme() + "://" + request.getServerName()
                        + (request.getServerPort() == 80 || request.getServerPort() == 443 ? "" : ":" + request.getServerPort());
                authService.solicitarRecuperacionContrasena(correo, baseUrl);
                redirectAttributes.addFlashAttribute("mensajeExito",
                        "Se ha enviado un enlace de recuperación a tu correo electrónico.");
            } catch (RuntimeException e) {
                redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
            }
            return "redirect:/";
        }

        @GetMapping("/restablecer-clave")
        public String mostrarRestablecerClave(@RequestParam("token") String token,
                                              Model model,
                                              RedirectAttributes redirectAttributes) {
            if (authService.validarTokenRecuperacion(token).isEmpty()) {
                redirectAttributes.addFlashAttribute("mensajeError", "El enlace de recuperación es inválido o ha expirado.");
                return "redirect:/";
            }
            model.addAttribute("token", token);
            return "restablecerClave";
        }

        @PostMapping("/restablecer-clave")
        public String procesarRestablecerClave(@RequestParam("token") String token,
                                               @RequestParam("nuevaContrasena") String nuevaContrasena,
                                               RedirectAttributes redirectAttributes) {
            try {
                authService.restablecerContrasena(token, nuevaContrasena);
                redirectAttributes.addFlashAttribute("mensajeExito",
                        "Contraseña actualizada correctamente. Ya puedes iniciar sesión.");
                return "redirect:/";
            } catch (RuntimeException e) {
                redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
                return "redirect:/restablecer-clave?token=" + token;
            }
        }

        @GetMapping("/logout")
        public String cerrarSesion(HttpSession session) {
            session.invalidate();
            return "redirect:/";
        }

        private String redirigirSegunRol(Usuario usuario) {
            String rol = usuario.getRol() != null ? usuario.getRol().getNombreRol() : "";
            if (rol.equalsIgnoreCase("Admin") || rol.equalsIgnoreCase("Administrador")) {
                return "redirect:/admin";
            } else if (rol.equalsIgnoreCase("Proveedor")) {
                return "redirect:/proveedor";
            }
            return "redirect:/usuario";
        }
    }

    @PostMapping("/recuperar-clave")
    public String solicitarRecuperacion(@RequestParam("correo") String correo,
                                        HttpServletRequest request,
                                        RedirectAttributes redirectAttributes) {
        try {
            String baseUrl = request.getScheme() + "://" + request.getServerName()
                    + (request.getServerPort() == 80 || request.getServerPort() == 443 ? "" : ":" + request.getServerPort());
            authService.solicitarRecuperacionContrasena(correo, baseUrl);
            redirectAttributes.addFlashAttribute("mensajeExito",
                    "Se ha enviado un enlace de recuperación a tu correo electrónico.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return "redirect:/";
    }

    @GetMapping("/restablecer-clave")
    public String mostrarRestablecerClave(@RequestParam("token") String token,
                                          Model model,
                                          RedirectAttributes redirectAttributes) {
        if (authService.validarTokenRecuperacion(token).isEmpty()) {
            redirectAttributes.addFlashAttribute("mensajeError", "El enlace de recuperación es inválido o ha expirado.");
            return "redirect:/";
        }
        model.addAttribute("token", token);
        return "restablecerClave";
    }

    @PostMapping("/restablecer-clave")
    public String procesarRestablecerClave(@RequestParam("token") String token,
                                           @RequestParam("nuevaContrasena") String nuevaContrasena,
                                           RedirectAttributes redirectAttributes) {
        try {
            authService.restablecerContrasena(token, nuevaContrasena);
            redirectAttributes.addFlashAttribute("mensajeExito",
                    "Contraseña actualizada correctamente. Ya puedes iniciar sesión.");
            return "redirect:/";
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
            return "redirect:/restablecer-clave?token=" + token;
        }
    }

    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    private String redirigirSegunRol(Usuario usuario) {
        String rol = usuario.getRol() != null ? usuario.getRol().getNombreRol() : "";
        if (rol.equalsIgnoreCase("Admin") || rol.equalsIgnoreCase("Administrador")) {
            return "redirect:/admin";
        } else if (rol.equalsIgnoreCase("Proveedor")) {
            return "redirect:/proveedor";
        }
        return "redirect:/usuario";
    }
}