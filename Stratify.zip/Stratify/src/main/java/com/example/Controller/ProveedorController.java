package com.example.Controller;

import com.example.entity.*;
import com.example.repository.ProveedorRepository;
import com.example.service.SolicitudService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.*;

@Controller
@RequiredArgsConstructor
public class ProveedorController {

    private final SolicitudService solicitudService;
    private final ProveedorRepository proveedorRepository;

    // =========================================================================
    // VISTA PRINCIPAL (THYMELEAF)
    // =========================================================================

    @GetMapping("/proveedor")
    public String vistaProveedor(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            return "redirect:/";
        }
        model.addAttribute("usuario", usuario);
        return "proveedor";
    }

    // =========================================================================
    // ENDPOINTS @GetMapping Y @PostMapping PARA proveedor.js
    // =========================================================================

    @GetMapping("/api/solicitudes")
    @ResponseBody
    public ResponseEntity<?> listarSolicitudesPendientes(HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        List> lista = new ArrayList<>();

        for (SolicitudProducto s : solicitudService.listarTodas()) {
            if (!"PENDIENTE".equalsIgnoreCase(s.getEstado())) continue;

            Map<String, Object> item = new HashMap<>();
            item.put("idSolicitud", s.getIdSolicitud());
            item.put("codigoProducto", s.getProducto() != null ? s.getProducto().getCodigoProducto() : "N/A");
            item.put("nombreCliente", s.getUsuario() != null
                    ? s.getUsuario().getNombre() + " " + s.getUsuario().getApellido() : "Cliente");
            item.put("nombreProducto", s.getProducto() != null ? s.getProducto().getNombre() : "Producto");
            item.put("cantidad", s.getCantidadSolicitada());
            item.put("fechaSolicitud", s.getFechaSolicitud() != null ? s.getFechaSolicitud().format(fmt) : "-");
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @PostMapping("/api/solicitudes/{id}/responder")
    @ResponseBody
    public ResponseEntity> responderSolicitud(@PathVariable Integer id,
                                              @RequestParam String accion,
                                              HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        try {
            boolean aceptar = "aceptar".equalsIgnoreCase(accion);
            solicitudService.responderSolicitud(
                    id,
                    aceptar ? "APROBADA" : "RECHAZADA",
                    aceptar ? "Solicitud aprobada por proveedor" : "Solicitud rechazada por proveedor",
                    aceptar,
                    usuario
            );
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/proveedores")
    @ResponseBody
    public ResponseEntity> crearProveedor(@RequestParam("nit_proveedor") String nit,
                                          @RequestParam("nombre_proveedor") String nombre,
                                          @RequestParam("telefono_proveedor") String telefono,
                                          @RequestParam(name = "email_proveedor", required = false) String email,
                                          @RequestParam(name = "direccion_proveedor", required = false) String direccion) {
        Map<String, Object> res = new HashMap<>();
        try {
            Proveedor p = new Proveedor();
            p.setNit(nit);
            p.setNombre(nombre);
            p.setTelefono(telefono);
            p.setCorreo(email);
            p.setDireccion(direccion);
            p.setEstado("Activo");
            proveedorRepository.save(p);

            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }
}