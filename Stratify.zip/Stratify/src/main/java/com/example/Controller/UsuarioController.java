package com.example.Controller;

import com.example.entity.*;
import com.example.repository.*;
import com.example.service.*;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.*;

@Controller
@RequiredArgsConstructor
public class UsuarioController {

    private final ProductoService productoService;
    private final InventarioService inventarioService;
    private final SolicitudService solicitudService;
    private final UsuarioService usuarioService;
    private final ProveedorRepository proveedorRepository;
    private final HistorialCambiosRepository historialCambioRepository;

    // =========================================================================
    // VISTA PRINCIPAL (THYMELEAF)
    // =========================================================================

    @GetMapping("/usuario")
    public String vistaUsuario(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            return "redirect:/";
        }
        model.addAttribute("usuario", usuario);
        return "usuario";
    }

    // =========================================================================
    // ENDPOINTS @GetMapping PARA app.js
    // =========================================================================

    @GetMapping("/api/inventario")
    @ResponseBody
    public ResponseEntity<?> listarInventario(HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        List > lista = new ArrayList<>();
        for (Producto p : productoService.listarActivos()) {
            int cant = p.getInventario() != null ? p.getInventario().getCantidadActual() : 0;
            int min = p.getInventario() != null ? p.getInventario().getStockMinimo() : 10;

            Map<String, Object> item = new HashMap<>();
            item.put("id_producto", p.getIdProducto());
            item.put("codigo_producto", p.getCodigoProducto());
            item.put("nombre_producto", p.getNombre());
            item.put("cantidad", cant);
            item.put("estado", cant == 0 ? "agotado" : (cant <= min ? "bajo" : "disponible"));
            item.put("nombre_proveedor", p.getProveedor() != null ? p.getProveedor().getNombre() : "Sin proveedor");
            item.put("inventario_id_inventario", p.getInventario() != null ? p.getInventario().getIdInventario() : null);
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/proveedores")
    @ResponseBody
    public ResponseEntity<?> listarProveedores(HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        List<Producto> todosProductos = productoService.listarTodos();
        List > lista = new ArrayList<>();

        for (Proveedor prov : proveedorRepository.findAll()) {
            long asociados = todosProductos.stream()
                    .filter(p -> p.getProveedor() != null && p.getProveedor().getIdProveedor().equals(prov.getIdProveedor()))
                    .count();

            Map<String, Object> item = new HashMap<>();
            item.put("id_proveedor", prov.getIdProveedor());
            item.put("nit_proveedor", prov.getNit());
            item.put("nombre_proveedor", prov.getNombre());
            item.put("email_proveedor", prov.getCorreo());
            item.put("telefono_proveedor", prov.getTelefono());
            item.put("direccion_proveedor", prov.getDireccion());
            item.put("productos_asociados", asociados);
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/proveedores/{id}/productos")
    @ResponseBody
    public ResponseEntity<?> productosDeProveedor(@PathVariable Integer id, HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        List > lista = new ArrayList<>();
        for (Producto p : productoService.listarTodos()) {
            if (p.getProveedor() != null && p.getProveedor().getIdProveedor().equals(id)) {
                Map<String, Object> item = new HashMap<>();
                item.put("id_producto", p.getIdProducto());
                item.put("codigo_producto", p.getCodigoProducto());
                item.put("nombre_producto", p.getNombre());
                item.put("stock", p.getInventario() != null ? p.getInventario().getCantidadActual() : 0);
                lista.add(item);
            }
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/historial")
    @ResponseBody
    public ResponseEntity<?> listarHistorial(HttpSession session) {
        if (session.getAttribute("usuarioLogueado") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        DateTimeFormatter fmtFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter fmtHora = DateTimeFormatter.ofPattern("HH:mm");

        List > lista = new ArrayList<>();
        for (HistorialCambio hc : historialCambioRepository.findTop50ByOrderByFechaCambioDesc()) {
            int ant = hc.getCantidadAnterior() != null ? hc.getCantidadAnterior() : 0;
            int nue = hc.getCantidadNueva() != null ? hc.getCantidadNueva() : 0;

            Map<String, Object> item = new HashMap<>();
            item.put("usuario", hc.getUsuario() != null ? hc.getUsuario().getNombre() : "Sistema");
            item.put("accion", hc.getTipoCambio() != null ? hc.getTipoCambio().toLowerCase() : "movimiento");
            item.put("objetivo", hc.getProducto() != null ? hc.getProducto().getNombre() : hc.getDescripcion());
            item.put("fecha", hc.getFechaCambio() != null ? hc.getFechaCambio().format(fmtFecha) : "");
            item.put("hora", hc.getFechaCambio() != null ? hc.getFechaCambio().format(fmtHora) : "");
            item.put("stock_anterior", ant);
            item.put("stock_nuevo", nue);
            item.put("cantidad_modificada", nue - ant);
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    // =========================================================================
    // ENDPOINTS @PostMapping PARA app.js
    // =========================================================================

    @PostMapping("/api/inventario/retiro")
    @ResponseBody
    public ResponseEntity>

    retirarStock(@RequestParam("producto_id") Integer productoId,
                 @RequestParam Integer cantidad,
                 @RequestParam(required = false) String descripcion,
                 HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        try {
            inventarioService.registrarSalida(productoId, cantidad, descripcion, usuario);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/solicitudes")
    @ResponseBody
    public ResponseEntity>

    crearSolicitud(@RequestParam("producto_id_producto") Integer idProducto,
                   @RequestParam Integer cantidad,
                   HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        try {
            solicitudService.crearSolicitud(idProducto, cantidad, "Solicitud de reabastecimiento", usuario);
            res.put("status", "success");
            res.put("exito", true);
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/usuario/perfil")
    @ResponseBody
    public ResponseEntity>

    actualizarPerfil(@RequestParam String nombre,
                     @RequestParam(required = false) String apellido,
                     @RequestParam(required = false) String email,
                     @RequestParam(required = false) String password,
                     HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        try {
            Usuario actualizado = usuarioService.actualizarPerfil(
                    usuario.getIdUsuario(),
                    nombre,
                    apellido != null ? apellido : usuario.getApellido(),
                    usuario.getNumeroDocumento(),
                    email != null ? email : usuario.getCorreo(),
                    usuario.getTelefono(),
                    password
            );
            session.setAttribute("usuarioLogueado", actualizado);
            res.put("status", "success");
            res.put("mensaje", "Perfil actualizado correctamente.");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }
}