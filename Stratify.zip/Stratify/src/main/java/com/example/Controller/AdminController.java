package com.example.Controller;

import com.example.entity.*;
import com.example.repository.*;
import com.example.service.*;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Controller
@RequiredArgsConstructor
public class AdminController {

    private final UsuarioService usuarioService;
    private final ProductoService productoService;
    private final InventarioService inventarioService;
    private final ProveedorRepository proveedorRepository;
    private final RolRepository rolRepository;

    private final UnidadMedidaRepository unidadMedidaRepository;
    private final UbicacionAlmacenRepository ubicacionAlmacenRepository;
    private final HistorialCambiosRepository historialCambioRepository;

    // =========================================================================
    // VISTA PRINCIPAL (THYMELEAF)
    // =========================================================================

    @GetMapping("/admin")
    public String vistaAdmin(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) {
            return "redirect:/";
        }
        String rol = usuario.getRol() != null ? usuario.getRol().getNombreRol() : "";
        if (!rol.equalsIgnoreCase("Admin") && !rol.equalsIgnoreCase("Administrador")) {
            return "redirect:/";
        }
        model.addAttribute("usuario", usuario);
        return "admin";
    }

    // =========================================================================
    // ENDPOINTS @GetMapping PARA admin.js
    // =========================================================================

    @GetMapping("/api/admin/estadisticas")
    @ResponseBody
    public ResponseEntity obtenerEstadisticas() {
        List<Usuario> todos = usuarioService.listarTodos();
        long activos = todos.stream()
                .filter(u -> "Activo".equalsIgnoreCase(u.getEstado()) && Boolean.TRUE.equals(u.getAutorizacion()))
                .count();
        long inhabilitados = todos.size() - activos;
        long admins = todos.stream()
                .filter(u -> u.getRol() != null &&
                        (u.getRol().getNombreRol().equalsIgnoreCase("Admin")
                                || u.getRol().getNombreRol().equalsIgnoreCase("Administrador")))
                .count();

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalClientes", todos.size());
        stats.put("clientesActivos", activos);
        stats.put("inhabilitados", inhabilitados);
        stats.put("administradores", admins);
        stats.put("eliminados", 0);
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/api/admin/clientes")
    @ResponseBody
    public ResponseEntity<List> listarClientes() {
        List lista = new ArrayList<>();
        for (Usuario u : usuarioService.listarTodos()) {
            String rolStr = "usuario";
            if (u.getRol() != null) {
                String nombreRol = u.getRol().getNombreRol().toLowerCase();
                if (nombreRol.contains("admin")) rolStr = "admin";
                else if (nombreRol.contains("prov")) rolStr = "proveedor";
            }
            boolean esActivo = "Activo".equalsIgnoreCase(u.getEstado()) && Boolean.TRUE.equals(u.getAutorizacion());

            Map<String, Object> item = new HashMap<>();
            item.put("id", u.getIdUsuario());
            item.put("nombre", u.getNombre() + " " + (u.getApellido() != null ? u.getApellido() : ""));
            item.put("email", u.getCorreo());
            item.put("telefono", u.getTelefono());
            item.put("documento", u.getNumeroDocumento());
            item.put("rol", rolStr);
            item.put("estado", esActivo ? "activo" : "inhabilitado");
            item.put("registro", u.getFechaRegistro() != null ? u.getFechaRegistro().toLocalDate().toString() : "—");
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/admin/productos")
    @ResponseBody
    public ResponseEntity<List> listarProductos() {
        List lista = new ArrayList<>();
        for (Producto p : productoService.listarTodos()) {
            Map<String, Object> item = new HashMap<>();
            item.put("id_producto", p.getIdProducto());
            item.put("codigo_producto", p.getCodigoProducto());
            item.put("nombre_producto", p.getNombre());
            item.put("cantidad", p.getInventario() != null ? p.getInventario().getCantidadActual() : 0);
            item.put("nombre_proveedor", p.getProveedor() != null ? p.getProveedor().getNombre() : "—");
            item.put("fecha_ingreso", p.getFechaCreacion() != null ? p.getFechaCreacion().toLocalDate().toString() : "—");
                item.put("fecha_vencimiento", "N/A");
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/admin/proveedores")
    @ResponseBody
    public ResponseEntity<List> listarProveedoresSelect() {
        List lista = new ArrayList<>();
        for (Proveedor pr : proveedorRepository.findAll()) {
            Map<String, Object> item = new HashMap<>();
            item.put("id_proveedor", pr.getIdProveedor());
            item.put("nombre_proveedor", pr.getNombre());
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/admin/roles")
    @ResponseBody
    public ResponseEntity<List> listarRoles() {
        List<Usuario> usuarios = usuarioService.listarTodos();
        List lista = new ArrayList<>();
        for (Rol r : rolRepository.findAll()) {
            long count = usuarios.stream()
                    .filter(u -> u.getRol() != null && u.getRol().getIdRol().equals(r.getIdRol()))
                    .count();
            Map<String, Object> item = new HashMap<>();
            item.put("id", r.getIdRol());
            item.put("nombre", r.getNombreRol());
            item.put("cantidad", count);
            item.put("permisos", List.of("Ver productos", "Ajustar stock", "Ver historial"));
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/admin/roles/{rolId}/permisos")
    @ResponseBody
    public ResponseEntity<List<String>> obtenerPermisosRol(@PathVariable Integer rolId) {
        if (rolId == 1 || rolId == 3) {
            return ResponseEntity.ok(List.of(
                    "Ver productos", "Crear producto", "Editar producto", "Eliminar producto",
                    "Ver clientes", "Editar cliente", "Cambiar rol", "Inhabilitar cliente",
                    "Ajustar stock", "Ver historial"
            ));
        }
        return ResponseEntity.ok(List.of("Ver productos", "Ver historial"));
    }

    @GetMapping("/api/admin/historial")
    @ResponseBody
    public ResponseEntity<List> listarHistorialAdmin() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        List lista = new ArrayList<>();
        for (HistorialCambios hc : historialCambioRepository.findTop50ByOrderByFechaCambioDesc()) {
            Map<String, Object> item = new HashMap<>();
            item.put("admin", hc.getUsuario() != null ? hc.getUsuario().getNombre() : "Sistema");
            item.put("accion", hc.getTipoCambio() != null ? hc.getTipoCambio().toLowerCase() : "actualizó");
            item.put("afectado", hc.getProducto() != null ? hc.getProducto().getNombre() : "Inventario");
            item.put("fecha", hc.getFechaCambio() != null ? hc.getFechaCambio().format(fmt) : "");
            item.put("tipo", "ENTRADA".equalsIgnoreCase(hc.getTipoCambio()) ? "green"
                    : ("SALIDA".equalsIgnoreCase(hc.getTipoCambio()) ? "red" : "gold"));
            lista.add(item);
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/api/admin/notificaciones")
    @ResponseBody
    public ResponseEntity<List> listarNotificaciones() {
        List notifs = new ArrayList<>();
        for (Producto p : productoService.listarStockBajo()) {
            int cant = p.getInventario() != null ? p.getInventario().getCantidadActual() : 0;
            Map<String, Object> item = new HashMap<>();
            item.put("id", p.getIdProducto());
            item.put("tipo", "red");
            item.put("icono", "⚠️");
            item.put("titulo", "Stock bajo: " + p.getNombre());
            item.put("desc", "Quedan " + cant + " unidades disponibles.");
            item.put("tiempo", "Hoy");
            item.put("leida", false);
            notifs.add(item);
        }
        return ResponseEntity.ok(notifs);
    }

    // =========================================================================
    // ENDPOINTS @PostMapping PARA admin.js (ADAPTADOS A UsuarioService)
    // =========================================================================

    @PostMapping("/api/admin/clientes/{id}/estado")
    @ResponseBody
    public ResponseEntity cambiarEstadoCliente(@PathVariable Integer id,
                                                @RequestParam boolean activar,
                                                @RequestParam(required = false) String motivo,
                                                HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario admin = (Usuario) session.getAttribute("usuarioLogueado");
        try {
            usuarioService.cambiarAutorizacionYEstado(id, activar, activar ? "Activo" : "Inactivo", admin);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/clientes/{id}/editar")
    @ResponseBody
    public ResponseEntity editarCliente(@PathVariable Integer id,
                                         @RequestParam String nombre,
                                         @RequestParam String email,
                                         @RequestParam(required = false) String telefono,
                                         @RequestParam String documento,
                                         HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario admin = (Usuario) session.getAttribute("usuarioLogueado");
        try {
            Usuario existente = usuarioService.buscarPorId(id)
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado."));

            Usuario datos = new Usuario();
            datos.setNombre(nombre);
            datos.setApellido(existente.getApellido());
            datos.setTelefono(telefono != null ? telefono : existente.getTelefono());
            datos.setCorreo(email);
            datos.setNumeroDocumento(documento);

            Integer idRol = existente.getRol() != null ? existente.getRol().getIdRol() : null;
            Integer idTipoDoc = existente.getTipoDocumento() != null ? existente.getTipoDocumento().getIdTipoDocumento() : null;

            usuarioService.actualizarUsuario(id, datos, idRol, idTipoDoc, admin);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/clientes/{id}/rol")
    @ResponseBody
    public ResponseEntity cambiarRolCliente(@PathVariable Integer id,
                                             @RequestParam String rol,
                                             HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario admin = (Usuario) session.getAttribute("usuarioLogueado");
        try {
            Integer idRol = rolRepository.findAll().stream()
                    .filter(r -> r.getNombreRol().toLowerCase().contains(rol.toLowerCase()))
                    .map(Rol::getIdRol)
                    .findFirst()
                    .orElse(2);

            Usuario existente = usuarioService.buscarPorId(id)
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado."));

            // Se crea un objeto limpio sin contraseña para evitar re-encriptar el hash actual
            Usuario datos = new Usuario();
            datos.setNombre(existente.getNombre());
            datos.setApellido(existente.getApellido());
            datos.setTelefono(existente.getTelefono());
            datos.setCorreo(existente.getCorreo());
            datos.setNumeroDocumento(existente.getNumeroDocumento());

            Integer idTipoDoc = existente.getTipoDocumento() != null ? existente.getTipoDocumento().getIdTipoDocumento() : null;

            usuarioService.actualizarUsuario(id, datos, idRol, idTipoDoc, admin);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/clientes/{id}/eliminar")
    @ResponseBody
    public ResponseEntity eliminarCliente(@PathVariable Integer id, HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario admin = (Usuario) session.getAttribute("usuarioLogueado");
        try {
            usuarioService.eliminarUsuario(id, admin);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/productos")
    @ResponseBody
    public ResponseEntity agregarProducto(@RequestParam String nombre,
                                           @RequestParam String codigo,
                                           @RequestParam Integer cantidad,
                                           @RequestParam("proveedor") Integer idProveedor,
                                           HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario admin = (Usuario) session.getAttribute("usuarioLogueado");
        try {
            Producto p = new Producto();
            p.setNombre(nombre);
            p.setCodigoProducto(codigo);
            p.setPrecioUnitario(BigDecimal.ZERO);

            Integer idUnidad = unidadMedidaRepository.findAll().stream()
                    .findFirst().map(UnidadMedida::getIdUnidad).orElse(1);
            Integer idUbicacion = ubicacionAlmacenRepository.findAll().stream()
                    .findFirst().map(UbicacionAlmacen::getIdUbicacion).orElse(1);

            productoService.crearProducto(p, idUnidad, idProveedor, idUbicacion, cantidad, 5, 100, admin);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/productos/{id}/stock")
    @ResponseBody
    public ResponseEntity ajustarStock(@PathVariable Integer id,
                                        @RequestParam Integer cantidad,
                                        @RequestParam String tipoAccion,
                                        @RequestParam(required = false) String motivo,
                                        HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario admin = (Usuario) session.getAttribute("usuarioLogueado");
        try {
            if ("INGRESO_STOCK".equalsIgnoreCase(tipoAccion)) {
                inventarioService.registrarEntrada(id, cantidad, motivo, admin);
            } else {
                inventarioService.registrarSalida(id, cantidad, motivo, admin);
            }
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/productos/{id}/eliminar")
    @ResponseBody
    public ResponseEntity eliminarProducto(@PathVariable Integer id, HttpSession session) {
        Map<String, Object> res = new HashMap<>();
        Usuario admin = (Usuario) session.getAttribute("usuarioLogueado");
        try {
            productoService.eliminarProducto(id, admin);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/roles")
    @ResponseBody
    public ResponseEntity crearRol(@RequestParam String nombre,
                                    @RequestParam(required = false) String descripcion) {
        Map<String, Object> res = new HashMap<>();
        try {
            Rol r = new Rol();
            r.setNombreRol(nombre);
            r.setDescripcion(descripcion);
            rolRepository.save(r);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", e.getMessage());
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/roles/{id}/eliminar")
    @ResponseBody
    public ResponseEntity eliminarRol(@PathVariable Integer id) {
        Map<String, Object> res = new HashMap<>();
        try {
            rolRepository.deleteById(id);
            res.put("status", "success");
        } catch (RuntimeException e) {
            res.put("status", "error");
            res.put("mensaje", "No se puede eliminar un rol que tiene usuarios asignados.");
        }
        return ResponseEntity.ok(res);
    }

    @PostMapping("/api/admin/roles/{rolId}/permisos")
    @ResponseBody
    public ResponseEntity guardarPermisos(@PathVariable Integer rolId,
                                           @RequestParam String permisos) {
        return ResponseEntity.ok(Map.of("status", "success"));
    }
}