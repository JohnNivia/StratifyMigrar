package com.example.Controller;

import com.example.entity.Usuario;
import com.example.service.InventarioService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/inventario")
@RequiredArgsConstructor
public class InventarioController {

    private final InventarioService inventarioService;

    @PostMapping("/entrada")
    public String registrarEntrada(@RequestParam("idProducto") Integer idProducto,
                                   @RequestParam("cantidad") int cantidad,
                                   @RequestParam(value = "motivo", required = false) String motivo,
                                   HttpSession session,
                                   HttpServletRequest request,
                                   RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            inventarioService.registrarEntrada(idProducto, cantidad, motivo, usuario);
            redirectAttributes.addFlashAttribute("mensajeExito", "Entrada de inventario registrada.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    @PostMapping("/salida")
    public String registrarSalida(@RequestParam("idProducto") Integer idProducto,
                                  @RequestParam("cantidad") int cantidad,
                                  @RequestParam(value = "motivo", required = false) String motivo,
                                  HttpSession session,
                                  HttpServletRequest request,
                                  RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            inventarioService.registrarSalida(idProducto, cantidad, motivo, usuario);
            redirectAttributes.addFlashAttribute("mensajeExito", "Salida de inventario registrada.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    @PostMapping("/ajuste")
    public String ajustarStock(@RequestParam("idProducto") Integer idProducto,
                               @RequestParam("nuevaCantidad") int nuevaCantidad,
                               @RequestParam(value = "motivo", required = false) String motivo,
                               HttpSession session,
                               HttpServletRequest request,
                               RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");
        if (usuario == null) return "redirect:/";

        try {
            inventarioService.ajustarStock(idProducto, nuevaCantidad, motivo, usuario);
            redirectAttributes.addFlashAttribute("mensajeExito", "Stock ajustado correctamente.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("mensajeError", e.getMessage());
        }
        return redirigirOrigen(request, usuario);
    }

    private String redirigirOrigen(HttpServletRequest request, Usuario usuario) {
        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isBlank()) {
            return "redirect:" + referer;
        }
        String rol = usuario.getRol().getNombreRol();
        return (rol.equalsIgnoreCase("Admin") || rol.equalsIgnoreCase("Administrador"))
                ? "redirect:/admin" : "redirect:/usuario";
    }
}