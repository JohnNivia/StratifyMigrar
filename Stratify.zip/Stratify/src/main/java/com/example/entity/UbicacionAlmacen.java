package com.example.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ubicacion_almacen")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UbicacionAlmacen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ubicacion")
    private Integer idUbicacion;

    @Column(name = "nombre", nullable = false, length = 100)
    private String nombre;

    @Column(name = "direccion", nullable = false, length = 200)
    private String direccion;

    @Column(name = "ciudad", length = 100)
    private String ciudad;

    @Column(name = "descripcion", length = 255)
    private String descripcion;

    @Column(name = "estado", length = 20)
    private String estado;
}