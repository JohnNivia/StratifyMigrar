package com.example.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "historial_admin")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HistorialAdmin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_historial_admin")
    private Integer idHistorialAdmin;

    @Column(name = "id_admin")
    private Integer idAdmin;

    @Column(name = "nombre_admin", length = 150)
    private String nombreAdmin;

    @Column(name = "accion", nullable = false, length = 100)
    private String accion;

    @Column(name = "tabla_afectada", length = 50)
    private String tablaAfectada;

    @Column(name = "detalle", columnDefinition = "TEXT")
    private String detalle;

    @Column(name = "fecha_accion", nullable = false)
    private LocalDateTime fechaAccion;

    @PrePersist
    protected void onCreate() {
        if (this.fechaAccion == null) {
            this.fechaAccion = LocalDateTime.now();
        }
    }
}